#define APP_NAME                "ESPURNA"
#define APP_VERSION             "1.13.0"
#define APP_REVISION            "d543fee"
#define APP_AUTHOR              "xose.perez@gmail.com"
#define APP_WEBSITE             "http://tinkerman.cat"
#define CFG_VERSION             3
