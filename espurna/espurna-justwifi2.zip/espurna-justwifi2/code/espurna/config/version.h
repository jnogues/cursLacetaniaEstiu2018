#define APP_NAME                "ESPURNA"
#define APP_VERSION             "1.12.7a"
#define APP_REVISION            "db84006"
#define APP_AUTHOR              "xose.perez@gmail.com"
#define APP_WEBSITE             "http://tinkerman.cat"
#define CFG_VERSION             3
